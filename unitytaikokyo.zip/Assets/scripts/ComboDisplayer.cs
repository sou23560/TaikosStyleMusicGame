using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class ComboDisplayer : MonoBehaviour
{
    private TextMeshProUGUI combo;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
